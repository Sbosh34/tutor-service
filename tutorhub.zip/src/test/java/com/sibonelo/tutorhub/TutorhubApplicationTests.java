package com.sibonelo.tutorhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
