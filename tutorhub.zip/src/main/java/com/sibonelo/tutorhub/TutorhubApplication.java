package com.sibonelo.tutorhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorhubApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorhubApplication.class, args);
	}

}
